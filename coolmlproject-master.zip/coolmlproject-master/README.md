# coolmlproject

This is an experiment to see how running an analysis written as an R package is possible with drake to run the actual code.

Install with `devtools::install_github("b-rodrigues/coolmlproject")`
