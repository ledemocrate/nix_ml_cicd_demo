get_predictions <- function(model, new_data){

  

}
